// Social Media Usage Tracker Overlay
function createWorkingOverlay() {
  // Remove existing
  const existing = document.getElementById('tracker-widget');
  if (existing) existing.remove();
  
  // Create overlay
  const overlay = document.createElement('div');
  overlay.id = 'tracker-widget';
  overlay.style.cssText = `
    position: fixed !important;
    top: 20px !important;
    right: 20px !important;
    width: 200px !important;
    background: #ef4444 !important;
    color: white !important;
    padding: 15px !important;
    border-radius: 10px !important;
    font-family: Arial, sans-serif !important;
    font-size: 14px !important;
    z-index: 999999 !important;
    box-shadow: 0 5px 20px rgba(0,0,0,0.4) !important;
    cursor: move !important;
    user-select: none !important;
  `;
  
  overlay.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
      <div style="font-weight: bold;">⚠️ LIMIT EXCEEDED!</div>
      <div id="close-btn" style="
        background: rgba(255,255,255,0.3);
        border: none;
        color: white;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        cursor: pointer;
        font-size: 14px;
        text-align: center;
        line-height: 18px;
      ">×</div>
    </div>
    <div style="font-size: 12px; margin-bottom: 8px;">44m / 5m used today</div>
    <div style="
      width: 100%;
      height: 4px;
      background: rgba(255,255,255,0.3);
      border-radius: 2px;
    ">
      <div style="
        height: 100%;
        background: #fca5a5;
        width: 100%;
        border-radius: 2px;
      "></div>
    </div>
    <div style="
      margin-top: 8px;
      padding: 8px;
      background: rgba(255,255,255,0.1);
      border-radius: 5px;
      font-size: 11px;
      text-align: center;
    ">Take a break!</div>
  `;
  
  document.body.appendChild(overlay);
  
  // Add minimize/restore functionality
  let isMinimized = false;
  
  function minimizeOverlay(e) {
    e.stopPropagation();
    
    overlay.style.width = '50px';
    overlay.style.height = '50px';
    overlay.style.padding = '8px';
    overlay.innerHTML = `
      <div style="text-align: center; font-size: 12px; cursor: pointer;" id="mini-widget">
        <div>📊</div>
        <div style="font-size: 10px;">44m</div>
      </div>
    `;
    isMinimized = true;
  }
  
  function restoreOverlay(e) {
    e.stopPropagation();
    if (!isMinimized) return;
    
    overlay.style.width = '200px';
    overlay.style.height = 'auto';
    overlay.style.padding = '15px';
    
    overlay.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
        <div style="font-weight: bold;">⚠️ LIMIT EXCEEDED!</div>
        <div id="close-btn" style="
          background: rgba(255,255,255,0.3);
          border: none;
          color: white;
          width: 20px;
          height: 20px;
          border-radius: 50%;
          cursor: pointer;
          font-size: 14px;
          text-align: center;
          line-height: 18px;
        ">×</div>
      </div>
      <div style="font-size: 12px; margin-bottom: 8px;">44m / 5m used today</div>
      <div style="
        width: 100%;
        height: 4px;
        background: rgba(255,255,255,0.3);
        border-radius: 2px;
      ">
        <div style="
          height: 100%;
          background: #fca5a5;
          width: 100%;
          border-radius: 2px;
        "></div>
      </div>
      <div style="
        margin-top: 8px;
        padding: 8px;
        background: rgba(255,255,255,0.1);
        border-radius: 5px;
        font-size: 11px;
        text-align: center;
      ">Take a break!</div>
    `;
    
    isMinimized = false;
    
    // Re-add close functionality
    const newCloseBtn = overlay.querySelector('#close-btn');
    newCloseBtn.addEventListener('click', minimizeOverlay);
  }
  
  // Handle clicks on overlay
  overlay.addEventListener('click', (e) => {
    if (e.target.id === 'close-btn') {
      minimizeOverlay(e);
    } else if (isMinimized) {
      restoreOverlay(e);
    }
  });
  
  const closeBtn = overlay.querySelector('#close-btn');
  closeBtn.addEventListener('click', minimizeOverlay);
  
  // Add drag functionality
  let isDragging = false;
  let startX, startY, initialX, initialY;
  
  overlay.addEventListener('mousedown', (e) => {
    if (e.target.id === 'close-btn') return;
    
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;
    initialX = overlay.offsetLeft;
    initialY = overlay.offsetTop;
    
    overlay.style.cursor = 'grabbing';
  });
  
  document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    
    const deltaX = e.clientX - startX;
    const deltaY = e.clientY - startY;
    
    overlay.style.left = (initialX + deltaX) + 'px';
    overlay.style.top = (initialY + deltaY) + 'px';
    overlay.style.right = 'auto';
  });
  
  document.addEventListener('mouseup', () => {
    if (isDragging) {
      isDragging = false;
      overlay.style.cursor = 'move';
    }
  });
  
  return overlay;
}

// Check if on social media and create overlay
if (window.location.hostname.includes('facebook.com')) {
  // Create overlay after a short delay
  setTimeout(() => {
    createWorkingOverlay();
  }, 1000);
}